package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile WebStore : Web URL Address</p>
     */
    public static Object Web_URL
     
    /**
     * <p>Profile WebStore :  Mail used to register in store.</p>
     */
    public static Object Register_Email
     
    /**
     * <p>Profile WebStore : Password needed for registration</p>
     */
    public static Object Reg_Password
     
    /**
     * <p>Profile WebStore : First name of  the user</p>
     */
    public static Object First_Name
     
    /**
     * <p>Profile WebStore : Last name of the user.</p>
     */
    public static Object Last_Name
     
    /**
     * <p>Profile WebStore : Username with space to check if matches on dashboard</p>
     */
    public static Object First_Name_Login
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            Web_URL = selectedVariables['Web_URL']
            Register_Email = selectedVariables['Register_Email']
            Reg_Password = selectedVariables['Reg_Password']
            First_Name = selectedVariables['First_Name']
            Last_Name = selectedVariables['Last_Name']
            First_Name_Login = selectedVariables['First_Name_Login']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
