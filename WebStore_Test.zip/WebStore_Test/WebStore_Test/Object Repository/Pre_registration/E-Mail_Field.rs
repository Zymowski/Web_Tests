<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>E-Mail field for registration</description>
   <name>E-Mail_Field</name>
   <tag></tag>
   <elementGuidId>4b92bd3d-20b7-42a4-9d5f-8751b705cb57</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;email_create&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
