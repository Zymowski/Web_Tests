<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Button to register</description>
   <name>Register_button</name>
   <tag></tag>
   <elementGuidId>53b2440c-308e-4a90-97e1-d8740891ccb6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[class=&quot;btn btn-default button button-medium exclusive&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
