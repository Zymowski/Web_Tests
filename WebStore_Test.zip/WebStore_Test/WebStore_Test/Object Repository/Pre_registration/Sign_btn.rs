<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Sign in button</description>
   <name>Sign_btn</name>
   <tag></tag>
   <elementGuidId>161dd613-3ec5-4717-8782-9d030cba77fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;login&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
