<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Date of birth - month</description>
   <name>DoB_Months</name>
   <tag></tag>
   <elementGuidId>df4133a1-9ce3-41df-8405-5151428108a8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[id=&quot;months&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
