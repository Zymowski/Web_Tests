<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Email already passed from previous window.</description>
   <name>Email_check</name>
   <tag></tag>
   <elementGuidId>bcdd47ab-4a15-47be-b107-153e046d983a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;email&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
