<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>First name field.</description>
   <name>First_name</name>
   <tag></tag>
   <elementGuidId>f77f61cb-1f94-4552-994c-f35de87f62a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer_firstname&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
