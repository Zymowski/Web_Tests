<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Date of birth - year.</description>
   <name>DoB_Years</name>
   <tag></tag>
   <elementGuidId>1e62df7f-150b-45e4-848d-fa90855d9941</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[id=&quot;years&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
