<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Special offers checkbox.</description>
   <name>SpecialOffer</name>
   <tag></tag>
   <elementGuidId>44992978-ce5a-4447-ab9b-1914236aa506</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;optin&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
