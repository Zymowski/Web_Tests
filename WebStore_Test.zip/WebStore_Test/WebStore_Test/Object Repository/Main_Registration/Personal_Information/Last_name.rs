<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Last name field.</description>
   <name>Last_name</name>
   <tag></tag>
   <elementGuidId>6ed883f4-4fde-470c-a400-b64da788dd80</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;customer_lastname&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
