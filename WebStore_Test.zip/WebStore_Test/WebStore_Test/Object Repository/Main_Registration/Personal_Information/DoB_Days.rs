<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Date of birth - day</description>
   <name>DoB_Days</name>
   <tag></tag>
   <elementGuidId>ebfab0c7-32ec-47e4-bf87-f9663c538c2d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[id=&quot;days&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
