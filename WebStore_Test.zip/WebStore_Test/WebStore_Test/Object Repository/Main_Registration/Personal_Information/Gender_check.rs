<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Gender checkbox. In this case male gender is picked.</description>
   <name>Gender_check</name>
   <tag></tag>
   <elementGuidId>082deb91-f2e0-4344-aeb3-a5d4603bce4c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;id_gender1&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
