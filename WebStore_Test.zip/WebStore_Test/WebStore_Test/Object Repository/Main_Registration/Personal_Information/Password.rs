<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Registration password field.</description>
   <name>Password</name>
   <tag></tag>
   <elementGuidId>e97ef306-4d27-452e-abbd-a6d5dcd26aa1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;passwd&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
