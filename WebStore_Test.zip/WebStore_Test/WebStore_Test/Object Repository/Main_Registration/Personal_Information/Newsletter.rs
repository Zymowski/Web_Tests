<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Newsletter checkbox</description>
   <name>Newsletter</name>
   <tag></tag>
   <elementGuidId>3caccdef-581a-4c3f-8804-49aff922f70c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;newsletter&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
