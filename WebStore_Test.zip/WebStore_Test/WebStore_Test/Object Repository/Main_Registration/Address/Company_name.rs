<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address company name.</description>
   <name>Company_name</name>
   <tag></tag>
   <elementGuidId>3135fc6e-0329-4441-88e6-8e0d95574d7e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;company&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
