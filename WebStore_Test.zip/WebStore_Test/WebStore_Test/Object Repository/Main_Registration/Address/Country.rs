<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address - country field.</description>
   <name>Country</name>
   <tag></tag>
   <elementGuidId>924aad39-370d-4287-8237-9706105079b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>select[id=&quot;id_country&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
