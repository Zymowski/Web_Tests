<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address - address_line2</description>
   <name>Address_Line2</name>
   <tag></tag>
   <elementGuidId>17c3d865-5414-4b23-ae8c-28a4232ce48b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;address2&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
