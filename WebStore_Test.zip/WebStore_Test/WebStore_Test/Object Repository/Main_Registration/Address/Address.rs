<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address - address field</description>
   <name>Address</name>
   <tag></tag>
   <elementGuidId>c441b61e-1c33-4643-ba17-ac535c4c8847</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;address1&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
