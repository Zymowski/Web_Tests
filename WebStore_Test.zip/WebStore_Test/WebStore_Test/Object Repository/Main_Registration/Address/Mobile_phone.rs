<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address-mobile phone.</description>
   <name>Mobile_phone</name>
   <tag></tag>
   <elementGuidId>23cb6cae-cf31-459d-ba53-402b48d0aa24</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;phone_mobile&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
