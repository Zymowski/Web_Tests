<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address - city field</description>
   <name>City</name>
   <tag></tag>
   <elementGuidId>2ae1b0ef-9577-4209-8487-21054e703da2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;city&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
