<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address last name.</description>
   <name>Last_name</name>
   <tag></tag>
   <elementGuidId>39dd7319-abfa-4730-b26b-652fea254935</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;lastname&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
