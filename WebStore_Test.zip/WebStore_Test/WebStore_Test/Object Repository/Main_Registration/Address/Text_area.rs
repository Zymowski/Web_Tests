<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address - text area</description>
   <name>Text_area</name>
   <tag></tag>
   <elementGuidId>cad1bb4e-4c5a-4066-9827-991089c68175</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>textarea[id=&quot;other&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
