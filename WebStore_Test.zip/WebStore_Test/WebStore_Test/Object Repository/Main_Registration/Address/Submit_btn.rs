<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Submit button.</description>
   <name>Submit_btn</name>
   <tag></tag>
   <elementGuidId>a050f31a-b960-49e7-8bfd-c62d284f0e41</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button[id=&quot;submitAccount&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
