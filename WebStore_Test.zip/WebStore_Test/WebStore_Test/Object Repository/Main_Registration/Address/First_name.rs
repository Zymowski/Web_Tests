<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>First name address information.</description>
   <name>First_name</name>
   <tag></tag>
   <elementGuidId>8e5ccc0e-f8c2-4b58-b0c6-6c17754b0930</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;firstname&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
