<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Address-postal code</description>
   <name>Post_code</name>
   <tag></tag>
   <elementGuidId>84884930-521f-4208-9121-3d9a6ccfb122</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;postcode&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
