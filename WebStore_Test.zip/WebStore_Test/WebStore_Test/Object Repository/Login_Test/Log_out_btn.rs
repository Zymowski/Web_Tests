<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Log out button.</description>
   <name>Log_out_btn</name>
   <tag></tag>
   <elementGuidId>e3316993-bf89-4cee-a665-7cc116986d37</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;logout&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
