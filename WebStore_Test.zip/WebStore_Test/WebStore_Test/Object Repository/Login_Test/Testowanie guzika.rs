<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Testowanie guzika</name>
   <tag></tag>
   <elementGuidId>cce0b6f5-ef80-4260-a051-c656bef4c20b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
