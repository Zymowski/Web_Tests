<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Password login field.</description>
   <name>Password_field</name>
   <tag></tag>
   <elementGuidId>81737c21-0bb5-421a-abf8-a4095167d891</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;passwd&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
