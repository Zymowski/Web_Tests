<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Email login field.</description>
   <name>Email_field</name>
   <tag></tag>
   <elementGuidId>75d9de31-45be-486c-a980-b245d3bd4c50</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>input[id=&quot;email&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
