<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Sign in button</description>
   <name>Sign_btn</name>
   <tag></tag>
   <elementGuidId>42628605-9944-4093-bfa3-35ea39b5ad5c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;login&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
