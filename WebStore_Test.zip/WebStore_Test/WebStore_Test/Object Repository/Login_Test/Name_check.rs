<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Checking the account name on dashboard.</description>
   <name>Name_check</name>
   <tag></tag>
   <elementGuidId>2424b104-ea7a-4c21-8023-4334b340c39e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[class=&quot;account&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
