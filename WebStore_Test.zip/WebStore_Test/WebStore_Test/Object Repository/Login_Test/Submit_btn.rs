<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Submit login button.</description>
   <name>Submit_btn</name>
   <tag></tag>
   <elementGuidId>b0d19d19-605c-4bb7-9fa2-d13b620e5ff4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button[id=&quot;SubmitLogin&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
