W przypadku gdy rejestracja się nie powiedzie z powodu istniejącego już użytkownika,
należy wprowadzić inne dane do zmiennych globalnych "należy zmienić email".